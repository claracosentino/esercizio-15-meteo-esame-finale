export type TemperaturaType = {
    "timepoint":number,
    "temp2m":number
}