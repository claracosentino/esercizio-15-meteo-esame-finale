export type SunriseSunsetType = {
    "sunrise": string,
	"sunset": string,
    "status": string,
    "dawn": string,
	"dusk": string,
}